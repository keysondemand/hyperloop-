# hyperloop-proto-testing
Test results :
https://docs.google.com/document/d/1pm4Uz7OLvltYJtkbCiyPXMq1JL4E02kCxpcP5-oFQPk/edit#heading=h.igt4udmxu3xy