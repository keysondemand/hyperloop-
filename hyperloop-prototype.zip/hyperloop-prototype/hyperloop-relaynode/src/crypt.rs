extern crate secp256k1;
use num_traits::AsPrimitive;
use web3::types::{Bytes};
use hex::{FromHex, encode};

use secp256k1::{ecdsa, Error, Message, PublicKey, Secp256k1, SecretKey, Signing, Verification};
use sha3::{Digest, Keccak256};

pub fn sign_message(private_key_hex: &str, message_bytes: &Bytes) -> Result<Bytes, Box<dyn std::error::Error>> {
    let secp = Secp256k1::new();
    let private_key_bytes = Vec::from_hex(private_key_hex).expect("Invalid private key hex string");

    // Signing msg with recovery to generate <RecoverableSignature>
    let signature = sign_recovery(&secp, &message_bytes.0, &private_key_bytes).unwrap();
    // Getting recovery Id from <RecoverableSignature> 
    let (recovery_id, serialize_sig) = signature.serialize_compact();
    // Converting <RecoverableSignature> to <Signature>
    let mut sig = signature.to_standard();
    // normalizing S value to low
    sig.normalize_s(); // to low S
    // println!(" SIG : {}",sig);
    let sig_vec = Vec::from_hex(sig.to_string()).unwrap();
    let mut rsv = Vec::new();
    if(sig_vec[3] == 33){
        rsv.extend_from_slice(&sig_vec[5..37]); // r
        rsv.extend_from_slice(&sig_vec[39..]); // s
    }
    else{
        rsv.extend_from_slice(&sig_vec[4..36]); // r
        rsv.extend_from_slice(&sig_vec[38..]); // s
    }
    let mut v: u8 = recovery_id.to_i32().try_into().unwrap();
    v = v + 27; // specific to evm chains {27, 28}
    // println!("Recovery ID : {}", v ); 
    rsv.push(v);

    let sig_bytes = Bytes::from(rsv); 
    Ok(sig_bytes)
}

fn sign_recovery<C: Signing>(
    secp: &Secp256k1<C>,
    msg: &[u8],
    seckey: &Vec<u8>,
) -> Result<ecdsa::RecoverableSignature, Error> {

    let mut hasher = Keccak256::new();
    hasher.update(&msg);
    let hash_result = hasher.finalize();
    let msg = Message::from_digest_slice(hash_result.as_ref())?;
    // println!("Keccak256 Hash : {}", msg);
    let secret_key = SecretKey::from_slice(&seckey)?;
    // let public_key = PublicKey::from_secret_key(&secp, &secret_key).serialize_uncompressed();
    // println!(" SIGNER : {:?}", encode(&public_key));
    Ok(secp.sign_ecdsa_recoverable(&msg, &secret_key))

}