// use core::macros::builtin;
use dotenv::dotenv;
use ethers::abi::AbiDecode;
use log::{info, warn};
use std::env;
use std::time::{SystemTime, UNIX_EPOCH};
use hex::FromHex;
use web3::futures::StreamExt;
use web3::types::{Address, Bytes, FilterBuilder, Log, U256, H256, U64, TransactionReceipt};
use web3::transports::WebSocket;
use web3::contract::{Contract, Options};
use web3::transports::Http;

use std::str::FromStr;
// use web3::ethabi::{encode, Bytes};
use web3::signing::{Key, SecretKeyRef,SecretKey};
use web3::Web3;


mod crypt;
// mod txn;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    dotenv().ok();
    env_logger::init();
    let mut request_sequence: u64 = 0;
    let mut revert_sequence: u64 = 0;
    let batch_interval_time = 1; // (seconds)
    let batch_size_limit = 1;

    let mut log_bytes: Vec<Bytes> = vec![];

    // let dest_chain_id: u64 = env::var("DEST_CHAIN_ID")?.parse::<u64>().expect("main: invalid conversion to u64");
    let dest_contract_string = env::var("DEST_CONTRACT_ADDR")?;
    // let dest_contract_address = dest_contract_string.parse::<Address>()?;

    // let src_chain_id: u64 = env::var("SRC_CHAIN_ID")?.parse::<u64>().expect("main: invalid conversion to u64");
    let source_contract_string = env::var("SRC_CONTRACT_ADDR")?;
    // let source_contract_address = source_contract_string.parse::<Address>()?;
    
    let args: Vec<String> = env::args().collect();

    let src_rpc_url = &args[2];
    let src_http = Http::new(&src_rpc_url.as_str()).unwrap();
    let src_web3 = web3::Web3::new(src_http);
    let src_contract_instance = Contract::from_json(
        src_web3.eth(),
        Address::from_str(&&source_contract_string.as_str()).unwrap(),
        include_bytes!("../abi/bridge_tx.json"),
    ).unwrap();

    let dest_rpc_url = &args[3];

    let dest_http = Http::new(dest_rpc_url.as_str()).expect("Invalid RPC");
    let dest_web3 = web3::Web3::new(dest_http);
    let dest_contract_instance = Contract::from_json(
        dest_web3.eth(),
        Address::from_str(&&dest_contract_string.as_str()).unwrap(),
        include_bytes!("../abi/bridge_rx.json"),
    ).unwrap();

    let src_web3_clone = src_web3;
    // let dest_web3_clone = dest_web3;
    
    // let source_rpc_url = env::var("SRC_RPC_SOCKET")?;
    let source_rpc_url = &args[4];
    let dest_rpc_url = &args[5];
    // Source
    let transport_src = WebSocket::new(source_rpc_url).await?;
    let web3_src = web3::Web3::new(transport_src);
    // Destination
    let transport_dest = WebSocket::new(&dest_rpc_url).await?;
    let web3_dest = web3::Web3::new(transport_dest);

    let filter_dest = FilterBuilder::default()
        .address(vec![dest_contract_string.parse().unwrap()])
        .topics(
            Some(vec![<[u8; 32]>::from_hex(
                "58a0fccf1eb85cda332f38b9e313c7038b9660e5fca029b6d4735ebefe4f7afd"
            ).unwrap().into()]),
            None,
            None,
            None,
        ).build();
    let filter_src = FilterBuilder::default()
        .address(vec![source_contract_string.parse().unwrap()])
        .topics(
            Some(vec![<[u8; 32]>::from_hex(
                "52cf04003d86066cd77e638acb2e47227554963812ac970787c2c5a161acf8a1"
            ).unwrap().into()]),
            None,
            None,
            None,
        ).build();

    let mut stream_dest = web3_dest.eth_subscribe().subscribe_logs(filter_dest).await?;
    let mut stream_src = web3_src.eth_subscribe().subscribe_logs(filter_src).await?;

    let interval_dur = std::time::Duration::from_secs(batch_interval_time);
    let mut interval = tokio::time::interval(interval_dur);
    
    tokio::spawn(async move {
        loop{
            tokio::select! {
                log = stream_dest.next() => {
                    if let Some(Ok(log)) = log {
                        //println!("Log: {:?}", log);
                        println!("REVERT EVENT DETECTED : {}", get_current_time());
                        // info!("REVERT EVENT DETECTED : {}", get_current_time());
                        let result = handle_revert(log).await;
                        match result.unwrap() {
                            Some(x) => {
                                revert_sequence = revert_sequence + 1;
                                let _ = process_log(&src_web3_clone, &src_contract_instance, &x, true, revert_sequence).await;
                            },
                            None => {}
                        }
                    }
                }
            }
        }
    });

    loop{
        tokio::select! {
            log = stream_src.next() => {
                if let Some(Ok(log)) = log {
                    //println!("Log: {:?}", log);
                    // LOG DETECTED
                    println!("EVENT DETECTED : {}", get_current_time());
                    // info!("EVENT DETECTED : {}", get_current_time());
                    let result = handle_log(log, &mut log_bytes).await;
                    match result.unwrap() {
                        Some(x) => {
                            // println!("X= {:?}", x);
                            request_sequence = request_sequence + 1;
                            let dest_contract_instance_clone = dest_contract_instance.clone();
                            let dest_web3_clone = dest_web3.clone();
                            tokio::spawn(async move {
                                let _ = process_log(&dest_web3_clone, &dest_contract_instance_clone, &x, false, request_sequence).await;
                            });
                        },
                        None => {}
                    }

                    if log_bytes.len() >= batch_size_limit {
                        let log_bytes_concatenate:Vec<u8> = log_bytes.clone().into_iter().flat_map(|bytes| bytes.0).collect();
                        log_bytes.clear();

                        let interval_dur = std::time::Duration::from_secs(batch_interval_time);
                        interval = tokio::time::interval(interval_dur);

                        let dest_contract_instance_clone = dest_contract_instance.clone();
                        let dest_web3_clone = dest_web3.clone();
                        tokio::spawn(async move {
                            let msg = Bytes::from(log_bytes_concatenate);
                            // println!("msg = {:?}",msg);
                            request_sequence = request_sequence + 1;
                            let _ = process_log(&dest_web3_clone, &dest_contract_instance_clone, &msg, false, request_sequence).await;
                        });
                    }
                }
            },
            _ = interval.tick() => {
                if !log_bytes.is_empty() {
                    let log_bytes_concatenate:Vec<u8> = log_bytes.clone().into_iter().flat_map(|bytes| bytes.0).collect();
                    log_bytes.clear();

                    let dest_contract_instance_clone = dest_contract_instance.clone();
                    let dest_web3_clone = dest_web3.clone();
                    tokio::spawn(async move {
                        let msg = Bytes::from(log_bytes_concatenate);
                        request_sequence = request_sequence + 1;
                        let _ = process_log(&dest_web3_clone, &dest_contract_instance_clone, &msg, false, request_sequence).await;
                    });
                }
                else {
                    // println!("~ No Transactions Pending ~\n");
                }
            }
        }
    }
}

async fn handle_log(log: Log, log_bytes: &mut Vec<Bytes>) -> Result< Option<Bytes>, Box<dyn std::error::Error>>{
    // println!("{}", log.topics[1]);
    // println!("{:?}", log.data);
    let emit_id = log.topics[1].to_low_u64_be();
    let block_time = log.topics[3].to_low_u64_be();
    println!("EMIT ID : {}", emit_id);
    println!("EMIT TIME : {}", block_time);
    // info!("EMIT ID : {}", emit_id);
    // info!("EMITTED AT : {}", block_time);
    // println!("LOGG : {:?}", log.data);
    // println!("LOGG : {:?}", log.data);


    let tx_array_len = log.data.0[63];
    println!("LEN  = {}", tx_array_len);

    if tx_array_len == 1 {
        log_bytes.push(log.data.clone());
        Ok(None)
    }
    else {
        let msg_bytes = log.data.clone();
        Ok(Some(msg_bytes))
    }
}

async fn handle_revert(log: Log) -> Result< Option<Bytes>,Box<dyn std::error::Error>> {
    // let emit_id = log.topics[1].to_low_u64_be();
    // let block_time = log.topics[3].to_low_u64_be();
    // println!("REVERT EMIT ID : {}", emit_id);
    // println!("REVERT EMIT TIME : {}", block_time);
    // info!("REVERT EMIT ID : {}", emit_id);
    // info!("REVERT EMITTED AT : {}", block_time);
    Ok(Some(log.data))
}

async fn process_log(provider_web3: &Web3<Http>, contract_instance: &Contract<Http>, msg: &Bytes, is_revert: bool, seq: u64) -> Result< (), Box<dyn std::error::Error>> {
    // if is_revert {
    //     println!("REVERT {} CALL BEGIN", seq);
    // }
    // else{
    //     println!("BATCH {} CALL BEGIN", seq);
    // }
    // println!("{} MSG: {:?}", seq, msg);
    //BYTES FORM OF MESSAGE
    //Sign the message
    let args: Vec<String> = env::args().collect();
    let private_key_hex = &args[1];
    
    let time_before_sign = get_current_time();
    let sig = crypt::sign_message(private_key_hex.as_str(), msg)?;
    let time_after_sign = get_current_time();
    // println!("{} SIG: {:?}", seq, sig);
    // println!("{} TIME TO HASH & SIGN : {}",seq, time_after_sign-time_before_sign);
    println!("TIME TO HASH & SIGN : {}",time_after_sign-time_before_sign);
    // info!("TIME TO HASH & SIGN: {}", time_after_sign-time_before_sign);

    // println!("{} TIME BEFORE CALLING EXECUTE : {}",seq, get_current_time());
    // println!("TIME BEFORE CALLING EXECUTE : {}",get_current_time());
    // info!("TIME BEFORE CALLING EXECUTE : {}", get_current_time());

    execute_message(provider_web3, &contract_instance, sig, msg.clone(), is_revert, seq).await?;
    
    // if is_revert {
    //     println!("REVERT {} CALL END", seq);
    // }
    // else{
    //     println!("BATCH {} CALL END", seq);
    // }

    Ok(())
}

async fn execute_message(provider_web3: &Web3<Http>, contract_instance: &Contract<Http>, sig: Bytes, txn: Bytes, is_revert: bool, seq: u64) -> Result< bool, Box<dyn std::error::Error>> {
    // let txn_send_timestamp = get_current_time();
    let params: (Bytes, Bytes) = (
        sig,
        txn
    );

    let args: Vec<String> = env::args().collect();
    let private_key_hex = &args[1];
    let pk = SecretKey::from_str(private_key_hex).unwrap();
    let pk_ref = SecretKeyRef::new(&pk);

    let mut options = Options::default();
    let gas_price = get_gas_price(provider_web3).await;
    let gas = env::var("GAS_LIMIT")?.parse()?;
    // let gas = if let Ok(gas_limit) = env::var("GAS_LIMIT") 
    // {
    //     let parsed_gas_limit: u64 = gas_limit.parse().expect("Invalid gas limit provided");
    //     U256::from(parsed_gas_limit)
    // } else {
    //     if is_revert{
    //         contract_instance.estimate_gas("revertTransaction", params.clone(), pk_ref.address(), options.clone()).await.expect("Unable to estimate gas")
    //     }
    //     else{
    //         contract_instance.estimate_gas("executeMessage", params.clone(), pk_ref.address(), options.clone()).await.expect("Unable to estimate gas")
    //     }
    // };
    options.gas_price = Some(gas_price);
    options.gas = Some(gas);


    let timestamp_txn_before = get_current_time();
    
    // info!("{} CALL TO CONTRACT INITIATED AT : {}",seq, timestamp_txn_before);


    if is_revert {
        println!("REVERT TX CALL INITIATED : {}", timestamp_txn_before);
        let tx = contract_instance.signed_call_with_confirmations("revertTransaction", params, options, 1 as usize,  pk_ref).await;
        let timestamp_txn_after = get_current_time();
        // println!("REVERT TX CALL COMPLETED : {}", timestamp_txn_after);
        // println!("REVERT TX CALL CONFIRMATION : {}", timestamp_txn_after - timestamp_txn_before);
        match tx {
            Ok(tx_receipt) => {
                // let receipt_str = serde_json::to_string(&tx_receipt).unwrap();
                // let _receipt: TransactionReceipt = serde_json::from_str(&receipt_str).unwrap();
                // println!("Transaction Receipt: {:?}", tx_receipt);
                if tx_receipt.status.unwrap() == U64::from(1){
                    println!("{} REVERT CALL TO SOURCE SUCCESS", seq);
                }
                Ok(true)
            },
            Err(e) => {
                let err_string = format!("{:?}", e);
                println!("{}", err_string);
                Ok(false)
            }
        }
    }
    else {
        println!("TX CALL INITIATED : {}", timestamp_txn_before);
        let tx = contract_instance.signed_call_with_confirmations("executeMessage", params, options, 1 as usize, pk_ref).await;
        // let timestamp_txn_after = get_current_time();
        // println!("TX CALL COMPLETED : {}", timestamp_txn_after);
        // println!("TX CALL CONFIRMATION : {}", timestamp_txn_after - timestamp_txn_before);

        match tx {
            Ok(tx_receipt) => {
                // let receipt_str = serde_json::to_string(&tx_receipt).unwrap();
                // let _receipt: TransactionReceipt = serde_json::from_str(&receipt_str).unwrap();
                // println!("Transaction Receipt: {:?}", tx_receipt);
                if tx_receipt.status.unwrap() == U64::from(1){
                    println!("{} CALL TO DEST SUCCESS", seq);
                }
                Ok(true)
            },
            Err(e) => {
                let err_string = format!("{:?}", e);
                println!("{}", err_string);
                Ok(false)
            }
        }
    }    

    
}

pub async fn get_gas_price(web3: &Web3<Http>) -> U256 {
    // if let Ok(gas_price) = dotenv::var("GAS_PRICE") {
    //     let gas_price: u64 = gas_price.parse().expect("Invalid gas price given");
    //     U256::from(gas_price)
    // } else {
    //     web3.eth().gas_price().await.expect("Unable to get gas price")
    // }
    let extra: u64 = dotenv::var("EXTRA_GAS_PRICE_FOR_QUICK_VALIDATION").unwrap().parse().expect("Invalid gas price given");;
    println!("EXTRAA {}", extra);
    return web3.eth().gas_price().await.expect("Unable to get gas price") + U256::from(extra);
}

fn get_current_time() -> u64{
    let now = SystemTime::now();
    let duration_since_epoch = now.duration_since(UNIX_EPOCH).unwrap();
    let unix_timestamp_millis = duration_since_epoch.as_secs() * 1000 + u64::from(duration_since_epoch.subsec_millis());

    unix_timestamp_millis
}