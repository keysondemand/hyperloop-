source .env

priv="NODE"$1"_PRIVATE_KEY"
src_url="SRC_RPC_URL"$1
dst_url="DEST_RPC_URL"$1
src_socket="SRC_RPC_SOCKET"$1
dst_socket="DEST_RPC_SOCKET"
cargo run ${!priv} ${!src_url} ${!dst_url} ${!src_socket} ${!dst_socket}