source .env
if [[ "$1" == "p" ]]; 
    then rpc=$POLYGON_AMOY_RPC_URL
elif [[ "$1" == "s" ]];
    then rpc=$SEPOLIA_RPC_URL
fi
forge script script/UpdateSigCommittee.s.sol --rpc-url $rpc --broadcast 